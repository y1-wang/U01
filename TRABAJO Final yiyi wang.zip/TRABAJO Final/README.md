# Práctica 1ª: To Do List
Esta práctica consiste en la creación de una lista de tareas, donde:
-Se añadan a la lista las tareas que hemos introducido.
-Borrarlas una vez realizadas.


## Estructura