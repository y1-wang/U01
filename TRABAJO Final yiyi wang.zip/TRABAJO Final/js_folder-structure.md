# JavaScript Documentation

## Folder/Files Structure