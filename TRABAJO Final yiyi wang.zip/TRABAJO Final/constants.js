//Forma simple
export const COMPANY='IES PIO BAROJA'
export const MODULE='Programación en Entorno Clientes'

//Forma Default
export default{
    COMP: 'IES PIO BAROJA', 
    MOD: 'Programación en Entorno Clientes'
}