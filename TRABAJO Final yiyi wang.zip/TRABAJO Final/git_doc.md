## Git 
1. Inicializar proyecto
```shell 
git init
```

2. Añadir ficheros
```shell 
git add * nombres_ficheros
```

3. Hacer paquete de commit
```shell
git commit -m "message commit"
```

4. Actualizar repositorio en Upstream
```shell
git pull #traer de Upstream
git push #subir a Upstream

```